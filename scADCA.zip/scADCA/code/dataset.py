import torch
from torch.utils.data import Dataset, DataLoader
import torchvision.transforms as transforms
import torch.nn.functional as F

import numpy as np
import pandas as pd

# 数据加载器
class Cell_Dataset(Dataset):
    def __init__(self, train_path):  
        self.train_path = train_path
        # 读取csv文件
        df = pd.read_csv(train_path)
        self.data = df.values

    def __len__(self): 
        return len(self.data)

    def __getitem__(self, index):
        return self.data[index]
        