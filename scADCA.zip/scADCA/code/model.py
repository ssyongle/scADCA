import torch
import torch.nn as nn

#  Conv1d + BN + LeakyReLU
class BasicConv(nn.Module):
    def __init__(self, in_channels, out_channels, kernel_size, stride=1):
        super(BasicConv, self).__init__()

        self.conv = nn.Conv1d(in_channels, out_channels, kernel_size, stride, kernel_size // 2, bias=True)
        self.bn = nn.BatchNorm1d(out_channels)  
        self.activation = nn.LeakyReLU()

    def forward(self, x):
        x = self.conv(x)
        x = self.bn(x)
        x = self.activation(x)
        return x


# FC + BN + LeakyReLU + dropout
class BasicFC(nn.Module):
    def __init__(self, in_channels, out_channels, dropout_opt=False):
        super(BasicFC, self).__init__()
        self.dropout_opt = dropout_opt
        self.fc = nn.Linear(in_channels, out_channels)
        self.bn = nn.BatchNorm1d(out_channels)  # 归一化
        self.activation = nn.LeakyReLU()
        self.dropout = nn.Dropout(p= 0.5)

    def forward(self, x):
        x = self.fc(x)
        # x = self.bn(x)
        x = self.activation(x)

        if self.dropout_opt:
            x = self.dropout(x)
        return x



# 自编码模型
class AutoEncoder(nn.Module):
    def __init__(self):
        super(AutoEncoder, self).__init__()
        self.multiConvs = nn.ModuleList()


        self.pool = nn.AvgPool1d(5, stride=5)

        for _ in range(5):
            self.multiConvs.append(nn.Sequential(
                BasicConv(1, 16, kernel_size=5),
                BasicConv(16, 16, kernel_size=5),
                BasicConv(16, 1, kernel_size=5),
                ))


        self.fc = nn.Sequential(
            BasicFC(5000, 256, dropout_opt = False),
            BasicFC(256, 16, dropout_opt = False),
            BasicFC(16, 256, dropout_opt = False),
            BasicFC(256, 5000, dropout_opt = False),
        )


    def forward(self, x):
        x = x.sigmoid()
        input_handle = x

        x = x.reshape([-1, 1, 5000])
        
        for i in range(5):
            residual = x
            x = self.multiConvs[i](x)
            x = residual + x

        x = x.reshape(-1, 5000)
        x = self.fc(x)
        x = x.sigmoid()

        return input_handle, x


