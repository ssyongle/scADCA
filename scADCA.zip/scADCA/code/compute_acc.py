import pandas as pd
import torch
import torch.nn as nn
from model import AutoEncoder
from dataset import Cell_Dataset
import numpy as np
import matplotlib.pyplot as plt
from collections import Counter
import seaborn as sns
import yaml
import sys
from sklearn.metrics import accuracy_score
import warnings
warnings.filterwarnings("ignore")
np.set_printoptions(threshold = np.inf) 
import multiprocessing

if __name__ == '__main__':
    multiprocessing.freeze_support()

    data_name = sys.argv[1] # 可选：Muraro, 10x_5cl, Segerstolpe

    # 模型路径
    weight = f'data/{data_name}/{data_name}.pt'

    # 测试集路径
    test_path = f'data/{data_name}/selected_test.csv'
    label_path = f'data/{data_name}/x_test_L.csv'

    # 超参数路径
    cfg_path = f'data/{data_name}/{data_name}.yaml'

    with open(cfg_path, 'rb') as f:
        cfg = yaml.load(f, yaml.SafeLoader)

    anomaly_threshold = cfg['anomaly_threshold'] # 异常阈值

    # 计算正确率
    def calculate_accuracy(y_true, y_pred):
        accuracy = accuracy_score(y_true, y_pred)
        return accuracy

    # 模型加载
    def model_load(weight_path):
        checkpoint = torch.load(weight_path, map_location= 'cpu')
        model = AutoEncoder()
        model.load_state_dict(checkpoint)
        model.eval()
        return model


    # 加载测试集数据和标签
    test_label = pd.read_csv(label_path)
    test_label = test_label.values.tolist()

    label_list = []
    for i in test_label:
        label_list.append(i[1])

    label = np.array(label_list)
    print("label:", label)

    # 加载模型
    model =  model_load(weight)
    criterion = nn.MSELoss()

    # 数据加载器
    test_dataset = Cell_Dataset(test_path)
    test_loader = torch.utils.data.DataLoader(
        test_dataset, batch_size=1, shuffle=False, num_workers=1, pin_memory=True)

    # 预测
    predict_list = []
    for i, data in enumerate(test_loader):
        data = data.float()
        input_handle, output = model(data)
        # compute mse_loss
        loss = criterion(output, input_handle)

        # 根据重构阈值预测已知细胞和未知细胞
        if loss.item() > anomaly_threshold:
            predict_list.append(1)
        else:
            predict_list.append(0)

    predict = np.array(predict_list)
    print("predict:", predict)


    # acc
    acc = calculate_accuracy(label, predict)

    print("acc:{}".format(acc, '.4f') )
