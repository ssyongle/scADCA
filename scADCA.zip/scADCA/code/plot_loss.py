import pandas as pd
import torch
import torch.nn as nn
from model import AutoEncoder
from dataset import Cell_Dataset
import numpy as np
import sys
import matplotlib.pyplot as plt
from collections import Counter
import seaborn as sns
import warnings
warnings.filterwarnings("ignore")
import multiprocessing

if __name__ == '__main__':
    multiprocessing.freeze_support()

    # 加载模型
    def model_load(weight_path):
        checkpoint = torch.load(weight_path, map_location= 'cpu')
        model = AutoEncoder()
        model.load_state_dict(checkpoint)
        model.eval()

        criterion = nn.MSELoss()

        return model, criterion

    # 数据加载器
    def create_dataloader(data_path):
        dataset = Cell_Dataset(data_path)
        dataloader = torch.utils.data.DataLoader(
            dataset, batch_size=1, shuffle=False, num_workers=1, pin_memory=True)
        return dataloader

    # 计算LOSS
    def compute_loss(dataloader, model, criterion):
        loss_list = []
        for i, data in enumerate(dataloader):
            data = data.float()
            input_handle, output = model(data)
            # compute mse_loss
            loss = criterion(output, input_handle)
            loss_list.append(loss.item())
        return loss_list

    # LOSS分布图
    def plot_loss(loss_list, save_name):
        loss_list = [round(i, 3) for i in loss_list]
        counter = sorted(Counter(loss_list).items())
        x_list = []
        y_list = []
        for x, y in counter:
            x_list.append(x)
            y_list.append(y)

        ax = sns.barplot(x=x_list, y=y_list)
        plt.xticks(rotation=45)

        ax.set(xlabel='mae_loss', ylabel='density')
        plt.tight_layout()

        plt.savefig(save_name)

    def test(weight_path, data_path, save_name):
        model, criterion = model_load(weight_path)
        dataloader = create_dataloader(data_path)
        loss_list = compute_loss(dataloader, model, criterion)
        plot_loss(loss_list, save_name)


    data_type = sys.argv[1] 
    weight = f'data/{data_type}/{data_type}.pt'
    train_path = f'data/{data_type}/selected_train.csv'
    test_path = f'data/{data_type}/selected_test.csv'


    test(weight, train_path, f"data/{data_type}/train_loss.png")

