import os
import random
import numpy as np
import yaml

import torch
import torch.nn as nn
from torch.cuda.amp import autocast, GradScaler

from dataset import Cell_Dataset
from model import AutoEncoder
import sys
import multiprocessing

if __name__ == '__main__':
    multiprocessing.freeze_support()
    # 设置随机种子
    def setup_seed(seed):
        torch.manual_seed(seed)
        np.random.seed(seed)
        random.seed(seed)
        torch.backends.cudnn.deterministic = True

    # 训练参数
    data_name = sys.argv[1] 
    train_path = f'D:\\Jupyter\\2C5221\\data/{data_name}/selected_train.csv'
    cfg_path = f'D:\\Jupyter\\2C5221\\data/{data_name}/{data_name}.yaml'

    with open(cfg_path, 'rb') as f:
        cfg = yaml.load(f, yaml.SafeLoader)

    setup_seed(cfg['seed'])  # 随机种子
    batch_size = cfg['batch_size']  # 训练批次
    epochs = cfg['epochs']  # 训练步数

    # 自编码模型
    model = AutoEncoder()

    # 损失函数
    criterion = nn.MSELoss()

    # 优化器
    optimizer = torch.optim.Adam(model.parameters(), lr=1e-3)

    # 混合精度训练
    scaler = GradScaler()

    # 学习率衰减
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=epochs, eta_min=1e-4)

    # 载入训练数据集
    train_dataset = Cell_Dataset(train_path)

    train_loader = torch.utils.data.DataLoader(
        train_dataset, batch_size=batch_size, shuffle=True, num_workers=1, pin_memory=True)

    # 训练
    for epoch in range(1, epochs):
        loss_all = 0
        model.train()
        for i, data in enumerate(train_loader):
            data = data.float()

            with autocast():
                # 前向传播
                input_handle, output = model(data)

                # 计算损失函数
                loss = criterion(output, input_handle)

            loss_all += loss.item() / len(train_dataset) * batch_size

            # 反向传播
            scaler.scale(loss).backward()
            scaler.step(optimizer)
            scaler.update()
            optimizer.zero_grad()

        # 学习率更新
        scheduler.step()

        # 打印训练信息
        print('Epoch: [{}]\t train_loss: {:.4f}\t'.format(epoch, loss_all))

        # model save
        checkpoint = './data/{}/{}.pt'.format(data_name, data_name)
        torch.save(model.state_dict(), checkpoint)

